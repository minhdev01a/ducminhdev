import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import datetime
import pytz
import json
import os
from typing import Dict, List

BOT_TOKEN = "8606340386:AAHVqxBcOWeP0OMCe1AKolHlp_PIq2AP0do"
OWNER = "minhduc"
ADMIN_ID = "conmeo991"  # Username của admin
MAIN_GROUP_ID = -5073346370  # ID nhóm chính để gửi thông báo

# API URL mới
API_URL = "http://192.168.1.2:2026/likes"

# Danh sách các nhóm được phép sử dụng bot (chat_id)
ALLOWED_GROUPS = [-5265041907]

# File lưu danh sách buff tự động
AUTO_BUFF_FILE = "auto_buff.json"

# File lưu danh sách nhóm được phép
ALLOWED_GROUPS_FILE = "allowed_groups.json"

# Múi giờ Việt Nam
VIETNAM_TZ = pytz.timezone('Asia/Ho_Chi_Minh')

class AllowedGroupsManager:
    def __init__(self, filename=ALLOWED_GROUPS_FILE):
        self.filename = filename
        self.groups = self.load_data()
    
    def load_data(self) -> List:
        """Đọc dữ liệu từ file"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Lỗi đọc file nhóm được phép: {e}")
                return []
        return []
    
    def save_data(self):
        """Lưu dữ liệu vào file"""
        try:
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(self.groups, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Lỗi ghi file nhóm được phép: {e}")
    
    def add_group(self, group_id: int, added_by: str, group_name: str = ""):
        """Thêm nhóm vào danh sách được phép"""
        # Kiểm tra xem nhóm đã tồn tại chưa
        for group in self.groups:
            if group["id"] == group_id:
                return False
        
        group_info = {
            "id": group_id,
            "name": group_name,
            "added_by": added_by,
            "added_at": datetime.datetime.now(VIETNAM_TZ).isoformat(),
            "status": "active"
        }
        self.groups.append(group_info)
        self.save_data()
        
        # Cập nhật cả biến ALLOWED_GROUPS để dùng trong code
        global ALLOWED_GROUPS
        ALLOWED_GROUPS = self.get_active_group_ids()
        
        return True
    
    def remove_group(self, group_id: int) -> bool:
        """Xóa nhóm khỏi danh sách được phép"""
        initial_count = len(self.groups)
        self.groups = [g for g in self.groups if g["id"] != group_id]
        if len(self.groups) < initial_count:
            self.save_data()
            
            # Cập nhật cả biến ALLOWED_GROUPS
            global ALLOWED_GROUPS
            ALLOWED_GROUPS = self.get_active_group_ids()
            
            return True
        return False
    
    def get_groups(self) -> List:
        """Lấy danh sách tất cả nhóm được phép"""
        return self.groups
    
    def get_active_group_ids(self) -> List:
        """Lấy danh sách ID các nhóm đang active"""
        return [g["id"] for g in self.groups if g.get("status") == "active"]
    
    def is_allowed(self, group_id: int) -> bool:
        """Kiểm tra nhóm có được phép không"""
        return group_id in self.get_active_group_ids()

class AutoBuffManager:
    def __init__(self, filename=AUTO_BUFF_FILE):
        self.filename = filename
        self.buff_list = self.load_data()
    
    def load_data(self) -> Dict:
        """Đọc dữ liệu từ file"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Lỗi đọc file: {e}")
                return {"jobs": []}
        return {"jobs": []}
    
    def save_data(self):
        """Lưu dữ liệu vào file"""
        try:
            with open(self.filename, 'w', encoding='utf-8') as f:
                json.dump(self.buff_list, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Lỗi ghi file: {e}")
    
    def add_job(self, uid: str, days: int, added_by: str):
        """Thêm công việc buff tự động"""
        # Kiểm tra xem UID đã tồn tại chưa
        for job in self.buff_list["jobs"]:
            if job["uid"] == uid:
                return None
        
        job = {
            "uid": uid,
            "days": days,
            "days_remaining": days,
            "added_by": added_by,
            "added_at": datetime.datetime.now(VIETNAM_TZ).isoformat(),
            "last_buff": None,
            "last_buff_result": None,
            "total_success": 0,
            "total_failed": 0,
            "status": "active"
        }
        self.buff_list["jobs"].append(job)
        self.save_data()
        return job
    
    def remove_job(self, uid: str) -> bool:
        """Xóa công việc buff tự động"""
        initial_count = len(self.buff_list["jobs"])
        self.buff_list["jobs"] = [j for j in self.buff_list["jobs"] if j["uid"] != uid]
        if len(self.buff_list["jobs"]) < initial_count:
            self.save_data()
            return True
        return False
    
    def get_jobs(self) -> List[Dict]:
        """Lấy danh sách công việc"""
        return self.buff_list["jobs"]
    
    def get_active_jobs(self) -> List[Dict]:
        """Lấy danh sách công việc đang active"""
        return [j for j in self.buff_list["jobs"] if j.get("status") == "active"]
    
    def update_last_buff(self, uid: str, success: bool, result_data: dict = None):
        """Cập nhật thông tin buff cuối cùng"""
        for job in self.buff_list["jobs"]:
            if job["uid"] == uid:
                job["last_buff"] = datetime.datetime.now(VIETNAM_TZ).isoformat()
                job["last_buff_result"] = {
                    "success": success,
                    "data": result_data,
                    "time": datetime.datetime.now(VIETNAM_TZ).isoformat()
                }
                if success:
                    job["total_success"] += 1
                    job["days_remaining"] -= 1
                else:
                    job["total_failed"] += 1
                
                # Nếu hết ngày hoặc failed quá nhiều thì dừng
                if job["days_remaining"] <= 0:
                    job["status"] = "completed"
                elif job["total_failed"] >= 3:
                    job["status"] = "failed"
                
                self.save_data()
                break
    
    def should_buff_today(self, job: Dict) -> bool:
        """Kiểm tra xem có cần buff hôm nay không"""
        if job.get("status") != "active":
            return False
        
        if not job.get("last_buff"):
            return True
        
        try:
            last_buff = datetime.datetime.fromisoformat(job["last_buff"])
            now = datetime.datetime.now(VIETNAM_TZ)
            
            # Kiểm tra nếu lần buff cuối cùng không phải hôm nay
            return last_buff.date() < now.date()
        except:
            return True

# Khởi tạo manager
auto_buff = AutoBuffManager()
allowed_groups = AllowedGroupsManager()

async def check_permission(update: Update) -> bool:
    """Kiểm tra quyền sử dụng bot"""
    chat = update.effective_chat
    user = update.effective_user
    
    # Kiểm tra nếu là admin
    if user and user.username == ADMIN_ID:
        return True
    
    # Nếu là chat cá nhân thì từ chối
    if chat.type == "private":
        await update.message.reply_text(
            "❌ Bạn Không Được Phép Sử Dụng Bot Này!\n"
            "Vui Lòng Liên Hệ @sixgai36 Để Được Cấp Quyền Hoặc Thêm Bot Vào Nhóm Đã Được Cho Phép.\n"
            "Mua Likes Giá Rẻ Nhất Thị Trường Vui Lòng Liên Hệ @sixgai36"
        )
        return False
    
    # Nếu là nhóm, kiểm tra trong danh sách được phép
    if chat.type in ["group", "supergroup"]:
        if allowed_groups.is_allowed(chat.id):
            return True
        else:
            await update.message.reply_text(
                "❌ Nhóm Của Bạn Chưa Được Cấp Quyền Sử Dụng Bot!\n"
                "Vui Lòng Liên Hệ @sixgai36 Để Được Cấp Quyền.\n"
                "Mua Likes Giá Rẻ Nhất Thị Trường Vui Lòng Liên Hệ @sixgai36"
            )
            return False
    
    return False

async def check_admin(update: Update) -> bool:
    """Kiểm tra quyền admin"""
    user = update.effective_user
    if user and user.username == ADMIN_ID:
        return True
    
    await update.message.reply_text(
        "❌ Chỉ admin mới có quyền sử dụng lệnh này!"
    )
    return False

async def like_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xử lý lệnh like và likes"""
    if not await check_permission(update):
        return
    
    if len(context.args) == 0:
        await update.message.reply_text("❌ Dùng: /like <uid> hoặc /likes <uid>")
        return

    uid = context.args[0]
    await perform_buff(update, uid, manual=True)

async def perform_buff(update: Update, uid: str, manual: bool = False, job_info: dict = None):
    """Thực hiện buff like"""
    params = {
        "uid": uid,
        "keys": "quametlon"  # Đã đổi key thành "An"
    }

    try:
        res = requests.get(API_URL, params=params, timeout=20)
        data = res.json()

        # Kiểm tra response từ API mới
        if not data.get("result"):
            error_msg = (
                "❌ Buff thất bại\n"
                "id này max 220 like hoặc Bot hết tài nguyên\n"
                "Vui lòng quay lại sau 24h"
            )
            
            if manual:
                await update.message.reply_text(error_msg)
            else:
                # Gửi thông báo thất bại vào nhóm chính
                await update.bot.send_message(
                    chat_id=MAIN_GROUP_ID,
                    text=f"❌ <b>AUTO BUFF THẤT BẠI</b>\n\n"
                         f"🆔 <b>UID:</b> {uid}\n"
                         f"📅 <b>Ngày còn lại:</b> {job_info['days_remaining'] if job_info else 'N/A'}\n"
                         f"❌ <b>Lý do:</b> Max like hoặc hết tài nguyên\n"
                         f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}",
                    parse_mode="HTML"
                )
            return False

        result = data["result"]
        api = result.get("API", {})
        likes = result.get("Likes Info", {})
        user = result.get("User Info", {})

        msg = (
            "✅ <b>API Success:</b> Ngon\n"
            f"⚡ <b>Speed:</b> {api.get('speeds','N/A')}\n\n"

            f"👤 <b>Tài Khoản:</b> {user.get('Tài khoản Name','N/A')}\n"
            f"🆔 <b>UID:</b> {user.get('Tài khoản UID','N/A')}\n"
            f"🔥 <b>Level:</b> {user.get('Tài khoản Level','N/A')}\n"
            f"🌍 <b>Sever:</b> {user.get('Tài khoản Region','N/A')}\n\n"

            f"💚 <b>Likes Tăng:</b> {likes.get('Likes Đã Thêm','0')}\n"
            f"📄 <b>Trước Khi Like:</b> {likes.get('Likes Trước','0')}\n"
            f"📈 <b>Sau Khi Like:</b> {likes.get('Likes Sau','0')}\n\n"

            f"☎ <b>Buy Likes, Please Contact:</b> @{OWNER}"
        )

        if manual:
            await update.message.reply_text(msg, parse_mode="HTML")
        else:
            # Gửi thông báo thành công vào nhóm chính
            auto_msg = (
                f"✅ <b>AUTO BUFF THÀNH CÔNG</b>\n\n"
                f"👤 <b>Tài Khoản:</b> {user.get('Account Name','N/A')}\n"
                f"🆔 <b>UID:</b> {user.get('Account UID','N/A')}\n"
                f"💚 <b>Likes Added:</b> {likes.get('Likes Added','0')}\n"
                f"📊 <b>Tiến trình:</b> {job_info['total_success'] + 1}/{job_info['days']} ngày\n"
                f"📅 <b>Ngày còn lại:</b> {job_info['days_remaining'] - 1}\n"
                f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}"
            )
            
            await update.bot.send_message(
                chat_id=MAIN_GROUP_ID,
                text=auto_msg,
                parse_mode="HTML"
            )
        
        return True

    except Exception as e:
        error_msg = (
            "❌ Buff thất bại\n"
            "id này max 220 like hoặc Bot hết tài nguyên\n"
            "Vui lòng quay lại sau 24h"
        )
        
        if manual:
            await update.message.reply_text(error_msg)
        else:
            # Gửi thông báo lỗi vào nhóm chính
            await update.bot.send_message(
                chat_id=MAIN_GROUP_ID,
                text=f"❌ <b>AUTO BUFF LỖI</b>\n\n"
                     f"🆔 <b>UID:</b> {uid}\n"
                     f"📅 <b>Ngày còn lại:</b> {job_info['days_remaining'] if job_info else 'N/A'}\n"
                     f"⚠️ <b>Lỗi:</b> {str(e)[:100]}\n"
                     f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}",
                parse_mode="HTML"
            )
        return False

async def autobuff_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Thêm UID vào danh sách buff tự động hàng ngày"""
    if not await check_admin(update):
        return
    
    if len(context.args) < 2:
        await update.message.reply_text(
            "❌ Dùng: /autobuff <uid> <số_ngày>\n"
            "Ví dụ: /autobuff 123456789 7"
        )
        return
    
    try:
        uid = context.args[0]
        days = int(context.args[1])
        
        if days <= 0:
            await update.message.reply_text("❌ Số ngày phải lớn hơn 0!")
            return
        
        # Kiểm tra UID đã tồn tại chưa
        existing_jobs = auto_buff.get_jobs()
        for job in existing_jobs:
            if job["uid"] == uid:
                await update.message.reply_text(f"❌ UID {uid} đã có trong danh sách buff tự động!")
                return
        
        # Thêm vào danh sách tự động
        job = auto_buff.add_job(uid, days, update.effective_user.username)
        
        if job:
            await update.message.reply_text(
                f"✅ Đã thêm UID {uid} vào danh sách buff tự động\n"
                f"📅 Số ngày: {days}\n"
                f"⏰ Sẽ buff lúc 4h sáng hàng ngày và thông báo kết quả tại nhóm"
            )
            
            # Thông báo vào nhóm chính
            await update.bot.send_message(
                chat_id=MAIN_GROUP_ID,
                text=f"✅ <b>THÊM AUTO BUFF MỚI</b>\n\n"
                     f"🆔 <b>UID:</b> {uid}\n"
                     f"📅 <b>Số ngày:</b> {days}\n"
                     f"👤 <b>Người thêm:</b> @{update.effective_user.username}\n"
                     f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}",
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(f"❌ Không thể thêm UID {uid}!")
        
    except ValueError:
        await update.message.reply_text("❌ Số ngày không hợp lệ!")

async def removebuff_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xóa UID khỏi danh sách buff tự động"""
    if not await check_admin(update):
        return
    
    if len(context.args) == 0:
        await update.message.reply_text("❌ Dùng: /removebuff <uid>")
        return
    
    uid = context.args[0]
    if auto_buff.remove_job(uid):
        await update.message.reply_text(f"✅ Đã xóa UID {uid} khỏi danh sách buff tự động")
        
        # Thông báo vào nhóm chính
        await update.bot.send_message(
            chat_id=MAIN_GROUP_ID,
            text=f"🛑 <b>DỪNG AUTO BUFF</b>\n\n"
                 f"🆔 <b>UID:</b> {uid}\n"
                 f"👤 <b>Người xóa:</b> @{update.effective_user.username}\n"
                 f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(f"❌ Không tìm thấy UID {uid} trong danh sách")

async def listbuff_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xem danh sách UID đang được buff tự động"""
    if not await check_admin(update):
        return
    
    # Lấy tất cả jobs
    all_jobs = auto_buff.get_jobs()
    active_jobs = auto_buff.get_active_jobs()
    
    if not active_jobs:
        # Kiểm tra nếu có jobs nhưng không active
        if all_jobs:
            msg = "📋 <b>DANH SÁCH BUFF TỰ ĐỘNG</b>\n\n"
            msg += "⚠️ <b>Không có job nào đang active:</b>\n"
            for job in all_jobs:
                msg += f"• UID {job['uid']} - Status: {job.get('status', 'unknown')}\n"
            await update.message.reply_text(msg, parse_mode="HTML")
        else:
            await update.message.reply_text("📭 Danh sách buff tự động đang trống")
        return
    
    msg = "📋 <b>DANH SÁCH BUFF TỰ ĐỘNG</b>\n\n"
    msg += f"📊 <b>Tổng số:</b> {len(active_jobs)} UID\n"
    msg += "──────────────────\n\n"
    
    for i, job in enumerate(active_jobs, 1):
        last_buff = "Chưa buff" if not job.get("last_buff") else datetime.datetime.fromisoformat(job["last_buff"]).strftime('%d/%m/%Y')
        last_result = "Chưa có" if not job.get("last_buff_result") else ("✅ Thành công" if job["last_buff_result"]["success"] else "❌ Thất bại")
        
        # Tính phần trăm hoàn thành
        percent = (job['total_success'] / job['days']) * 100 if job['days'] > 0 else 0
        
        msg += (
            f"<b>{i}. UID:</b> <code>{job['uid']}</code>\n"
            f"   📊 <b>Tiến trình:</b> {job['total_success']}/{job['days']} ngày ({percent:.1f}%)\n"
            f"   📅 <b>Còn lại:</b> {job['days_remaining']} ngày\n"
            f"   📈 <b>Thành công:</b> {job['total_success']} | ❌ <b>Thất bại:</b> {job['total_failed']}\n"
            f"   👤 <b>Người thêm:</b> @{job['added_by']}\n"
            f"   ⏰ <b>Buff lần cuối:</b> {last_buff} ({last_result})\n"
        )
        
        # Thêm warning nếu gần hết ngày hoặc failed nhiều
        if job['days_remaining'] <= 2:
            msg += f"   ⚠️ <b>Sắp hết hạn!</b>\n"
        if job['total_failed'] >= 2:
            msg += f"   ⚠️ <b>Failed nhiều!</b>\n"
        
        msg += "──────────────────\n"
    
    # Thêm thống kê
    total_success = sum(j['total_success'] for j in active_jobs)
    total_failed = sum(j['total_failed'] for j in active_jobs)
    msg += f"\n📊 <b>Tổng kết:</b>\n"
    msg += f"✅ Thành công: {total_success} lần\n"
    msg += f"❌ Thất bại: {total_failed} lần\n"
    
    await update.message.reply_text(msg, parse_mode="HTML")

async def allowgroup_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Thêm nhóm vào danh sách được phép (chỉ admin)"""
    if not await check_admin(update):
        return
    
    chat = update.effective_chat
    
    # Nếu đang ở trong nhóm và không có argument
    if len(context.args) == 0 and chat.type in ["group", "supergroup"]:
        group_id = chat.id
        group_name = chat.title or "Không có tên"
        
        if allowed_groups.add_group(group_id, update.effective_user.username, group_name):
            await update.message.reply_text(
                f"✅ Đã thêm nhóm này vào danh sách được phép!\n"
                f"📌 ID: {group_id}\n"
                f"📌 Tên: {group_name}"
            )
            
            # Thông báo vào nhóm chính
            await update.bot.send_message(
                chat_id=MAIN_GROUP_ID,
                text=f"✅ <b>THÊM NHÓM ĐƯỢC PHÉP</b>\n\n"
                     f"📌 <b>ID:</b> <code>{group_id}</code>\n"
                     f"📌 <b>Tên:</b> {group_name}\n"
                     f"👤 <b>Người thêm:</b> @{update.effective_user.username}\n"
                     f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}",
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text("❌ Nhóm này đã có trong danh sách được phép!")
    
    # Nếu có argument là group_id
    elif len(context.args) >= 1:
        try:
            group_id = int(context.args[0])
            group_name = " ".join(context.args[1:]) if len(context.args) > 1 else "Không có tên"
            
            if allowed_groups.add_group(group_id, update.effective_user.username, group_name):
                await update.message.reply_text(
                    f"✅ Đã thêm nhóm ID {group_id} vào danh sách được phép!"
                )
                
                # Thông báo vào nhóm chính
                await update.bot.send_message(
                    chat_id=MAIN_GROUP_ID,
                    text=f"✅ <b>THÊM NHÓM ĐƯỢC PHÉP</b>\n\n"
                         f"📌 <b>ID:</b> <code>{group_id}</code>\n"
                         f"📌 <b>Tên:</b> {group_name}\n"
                         f"👤 <b>Người thêm:</b> @{update.effective_user.username}\n"
                         f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}",
                    parse_mode="HTML"
                )
            else:
                await update.message.reply_text(f"❌ Nhóm ID {group_id} đã có trong danh sách được phép!")
        except ValueError:
            await update.message.reply_text("❌ ID nhóm không hợp lệ!")
    else:
        await update.message.reply_text(
            "❌ Cách dùng:\n"
            "• /allowgroup (khi đang ở trong nhóm)\n"
            "• /allowgroup <group_id> [tên_nhóm]"
        )

async def removegroup_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xóa nhóm khỏi danh sách được phép (chỉ admin)"""
    if not await check_admin(update):
        return
    
    if len(context.args) == 0:
        await update.message.reply_text("❌ Dùng: /removegroup <group_id>")
        return
    
    try:
        group_id = int(context.args[0])
        if allowed_groups.remove_group(group_id):
            await update.message.reply_text(f"✅ Đã xóa nhóm ID {group_id} khỏi danh sách được phép")
            
            # Thông báo vào nhóm chính
            await update.bot.send_message(
                chat_id=MAIN_GROUP_ID,
                text=f"🛑 <b>XÓA NHÓM ĐƯỢC PHÉP</b>\n\n"
                     f"📌 <b>ID:</b> <code>{group_id}</code>\n"
                     f"👤 <b>Người xóa:</b> @{update.effective_user.username}\n"
                     f"⏰ <b>Thời gian:</b> {datetime.datetime.now(VIETNAM_TZ).strftime('%H:%M:%S %d/%m/%Y')}",
                parse_mode="HTML"
            )
        else:
            await update.message.reply_text(f"❌ Không tìm thấy nhóm ID {group_id} trong danh sách")
    except ValueError:
        await update.message.reply_text("❌ ID nhóm không hợp lệ!")

async def listgroups_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xem danh sách nhóm được phép (chỉ admin)"""
    if not await check_admin(update):
        return
    
    groups = allowed_groups.get_groups()
    
    if not groups:
        await update.message.reply_text("📭 Danh sách nhóm được phép đang trống")
        return
    
    msg = "📋 <b>DANH SÁCH NHÓM ĐƯỢC PHÉP</b>\n\n"
    msg += f"📊 <b>Tổng số:</b> {len(groups)} nhóm\n"
    msg += "──────────────────\n\n"
    
    for i, group in enumerate(groups, 1):
        added_time = datetime.datetime.fromisoformat(group['added_at']).strftime('%d/%m/%Y %H:%M')
        msg += (
            f"<b>{i}. ID:</b> <code>{group['id']}</code>\n"
            f"   📌 <b>Tên:</b> {group.get('name', 'Không có tên')}\n"
            f"   👤 <b>Người thêm:</b> @{group['added_by']}\n"
            f"   ⏰ <b>Thời gian:</b> {added_time}\n"
            f"   📊 <b>Trạng thái:</b> {'✅ Active' if group.get('status') == 'active' else '❌ Inactive'}\n"
        )
        msg += "──────────────────\n"
    
    await update.message.reply_text(msg, parse_mode="HTML")

async def check_autobuff(context: ContextTypes.DEFAULT_TYPE):
    """Kiểm tra và thực hiện buff tự động (chạy mỗi phút)"""
    now = datetime.datetime.now(VIETNAM_TZ)
    
    # Chỉ chạy lúc 4h sáng
    if now.hour == 4 and now.minute == 0:
        print(f"🕐 Bắt đầu auto buff lúc {now.strftime('%H:%M:%S %d/%m/%Y')}")
        jobs = auto_buff.get_active_jobs()
        
        print(f"📋 Tìm thấy {len(jobs)} job cần buff")
        
        for job in jobs:
            if auto_buff.should_buff_today(job):
                print(f"🔄 Đang buff cho UID: {job['uid']}")
                
                # Tạo update giả để gửi thông báo
                class FakeUpdate:
                    def __init__(self, bot):
                        self.bot = bot
                        self.message = None
                
                fake_update = FakeUpdate(context.bot)
                
                # Thực hiện buff
                success = await perform_buff(fake_update, job["uid"], manual=False, job_info=job)
                
                # Cập nhật thông tin
                auto_buff.update_last_buff(job["uid"], success, None)
                
                print(f"{'✅' if success else '❌'} Kết quả buff UID {job['uid']}: {'Thành công' if success else 'Thất bại'}")
            else:
                print(f"⏸️ UID {job['uid']} đã được buff hôm nay")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Xử lý lệnh help"""
    if not await check_permission(update):
        return
    
    user = update.effective_user
    is_admin = user and user.username == ADMIN_ID
    
    help_text = (
        "🔴 <b>Hướng dẫn sử dụng Bot:</b>\n\n"
        "<b>Các lệnh có sẵn:</b>\n"
        "• /like [uid] - Buff like cho UID\n"
        "• /likes [uid] - Buff like cho UID\n"
        "• /help - Hiển thị hướng dẫn này\n"
    )
    
    if is_admin:
        help_text += (
            "\n<b>LỆNH ADMIN:</b>\n"
            "• /autobuff [uid] [số_ngày] - Thêm UID vào danh sách buff tự động (4h sáng)\n"
            "• /removebuff [uid] - Xóa UID khỏi danh sách buff tự động\n"
            "• /listbuff - Xem danh sách UID đang được buff tự động\n"
            "• /allowgroup - Thêm nhóm hiện tại vào danh sách được phép\n"
            "• /allowgroup [group_id] [tên] - Thêm nhóm theo ID\n"
            "• /removegroup [group_id] - Xóa nhóm khỏi danh sách được phép\n"
            "• /listgroups - Xem danh sách nhóm được phép\n"
        )
    
    help_text += f"\n<b>Liên hệ mua likes giá rẻ:</b> @{OWNER}"
    
    await update.message.reply_text(help_text, parse_mode="HTML")

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    
    # Thêm handler cho các lệnh
    app.add_handler(CommandHandler("like", like_command))
    app.add_handler(CommandHandler("likes", like_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("autobuff", autobuff_command))
    app.add_handler(CommandHandler("removebuff", removebuff_command))
    app.add_handler(CommandHandler("listbuff", listbuff_command))
    app.add_handler(CommandHandler("allowgroup", allowgroup_command))
    app.add_handler(CommandHandler("removegroup", removegroup_command))
    app.add_handler(CommandHandler("listgroups", listgroups_command))
    
    # Thêm job kiểm tra tự động mỗi phút
    job_queue = app.job_queue
    job_queue.run_repeating(check_autobuff, interval=60, first=10)
    
    print("🤖 Bot đang chạy...")
    print(f"📊 API URL: {API_URL}?keys=An&uid={{uid}}")
    print(f"👤 Admin: @{ADMIN_ID}")
    print(f"📢 Nhóm thông báo: {MAIN_GROUP_ID}")
    
    # Kiểm tra danh sách nhóm được phép
    allowed_group_ids = allowed_groups.get_active_group_ids()
    print(f"📋 Danh sách nhóm được phép: {allowed_group_ids if allowed_group_ids else 'Chưa có nhóm nào'}")
    
    # Kiểm tra dữ liệu buff hiện có
    jobs = auto_buff.get_jobs()
    print(f"📋 Số jobs trong danh sách: {len(jobs)}")
    if jobs:
        print("Chi tiết jobs:")
        for job in jobs:
            print(f"  - UID: {job['uid']}, Status: {job.get('status', 'unknown')}")
    
    app.run_polling()